class Constant {
  static const assetsImage = 'assets/images';
}