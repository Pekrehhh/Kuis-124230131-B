import 'package:flutter/material.dart';
import 'login_page.dart';
import 'detail_page.dart';
// ignore: unused_import
import 'game_model.dart';
import 'model_data.dart';

class HomePage extends StatelessWidget {
  final String username;
  const HomePage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Halo @$username',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (context) {
                  return LoginPage();
                },
              ), 
              (route) => false
            );
          }, 
          icon: Icon(Icons.logout_outlined))
        ],
      ),
      body: Center(
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16
                  ),
                  itemBuilder: (context, index) {
                    return _gameStore(context, index);
                  },
                  itemCount: gameList.length,
                ),
              )
            )
          ],
        ),
      ),
    );
  }

  Widget _gameStore(context, int index) {
    return InkWell(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) {
          return DetailPage(index: index, GameModel: gameList[index],);
        }));
      },
      child: Container(
        decoration:BoxDecoration(
          color: const Color.fromARGB(255, 209, 231, 241),
          // border: Border.all(width: 1),
          borderRadius:BorderRadius.circular(20)
        ),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
              child: Image.network(gameList[index].gameImg[0]),
            ),
            Text(gameList[index].gameName),
            Text(gameList[index].gamePublisher),
            Text(gameList[index].gamePublishDate),
            Text(gameList[index].gameDesc),
          ],
        ),
      ),
    );
  }
}