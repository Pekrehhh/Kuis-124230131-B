import 'package:flutter/material.dart';
import 'game_model.dart';
import 'model_data.dart';

class DetailPage extends StatelessWidget {
  final int index;
  const DetailPage({super.key, required this.index, required GameModel GameModel});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Detail Page")),
      body: Column(
        children: [
          Image.network(gameList[index].gameImg[0]),
          Text(gameList[index].gameName),
          Text(gameList[index].gamePublisher),
          Text(gameList[index].gamePublishDate),
          Text(gameList[index].gameDesc),
        ],
      ),
    );
  }
}